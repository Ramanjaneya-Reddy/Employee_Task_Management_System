
<div class="row">
<div class="gap"></div>
<div class="gap"></div>
  <div class="col-md-12">

    <div class="well">
      <div class="row">
        <div class="col-md-12 text-center">
          <marquee><span style="color: green;"> Hello <strong><?php echo $user_name; ?></strong>. Welcome to <strong> Employee Time Management</strong></span></marquee>
        </div>
      </div>
    </div>
  </div>
</div>